#pragma once

#include "appservice.h"

class JsonStorageService : public AppService {
public:
    JsonStorageService();

    QString storageRoot() const override;
    QList<QVariantMap> loadPageRecords(const QString &pageId) const override;
    bool upsertRecord(const QString &pageId, QVariantMap record, QString *errorMessage = nullptr) const override;
    bool removeRecord(const QString &pageId, const QString &id, QString *errorMessage = nullptr) const override;
    bool importExcel(const QString &pageId,
                     const QList<FieldDefinition> &fields,
                     const QString &filePath,
                     QString *errorMessage = nullptr) const override;
    bool exportExcel(const QString &pageId,
                     const QList<FieldDefinition> &fields,
                     const QString &sheetName,
                     const QString &filePath,
                     QString *errorMessage = nullptr) const override;
    QList<QVariantMap> loadInventoryHistory() const override;
    bool applyInventoryChange(const QVariantMap &itemData,
                              InventoryOperationType operationType,
                              InventoryInputType inputType,
                              const QString &note = QString(),
                              const QString &sourceFile = QString(),
                              int sourceRow = 0,
                              QString *errorMessage = nullptr) const override;
    bool importInventoryExcel(const QList<FieldDefinition> &fields,
                              const QString &filePath,
                              InventoryOperationType operationType,
                              QString *errorMessage = nullptr) const override;
    bool importInventoryBom(const QString &filePath,
                            InventoryOperationType operationType,
                            QString *errorMessage = nullptr) const override;
    bool analyzeInventoryFulfillment(const QString &filePath,
                                     QList<InventoryFulfillmentResult> *results,
                                     QString *errorMessage = nullptr) const override;
    bool enrichInventoryRecord(const QString &manufacturerPart,
                               const QVariantMap &currentRecord,
                               const QStringList &desiredFieldKeys,
                               InventoryEnrichmentResult *result,
                               QString *errorMessage = nullptr) const override;
    bool exportInventoryFulfillment(const QList<InventoryFulfillmentResult> &results,
                                    const QString &filePath,
                                    QString *errorMessage = nullptr) const override;
    bool applyInventoryFulfillment(const QList<InventoryFulfillmentResult> &results,
                                   QString *errorMessage = nullptr) const override;
    bool loadReimbursementAttachments(const QVariantMap &record,
                                      QList<ReimbursementAttachmentContent> *attachments,
                                      QString *errorMessage = nullptr) const override;

private:
    QString pageFilePath(const QString &pageId) const;
    QString attachmentsRootDirectory() const;
    QString recordAttachmentRelativeDirectory(const QString &pageId, const QString &recordId) const;
    QString recordAttachmentDirectory(const QString &pageId, const QString &recordId) const;
    QString inventoryHistoryFilePath() const;
    bool ensureStorageReady(QString *errorMessage = nullptr) const;
    bool archiveReimbursementAttachments(QVariantMap *record,
                                        const QVariantMap &existingRecord,
                                        QStringList *obsoleteFiles,
                                        QStringList *createdFiles,
                                        QString *errorMessage = nullptr) const;
    bool savePageRecords(const QString &pageId,
                         const QList<QVariantMap> &records,
                         QString *errorMessage = nullptr) const;
    bool saveInventoryHistory(const QList<QVariantMap> &records,
                              QString *errorMessage = nullptr) const;
};