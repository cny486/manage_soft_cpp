#pragma once

#include <functional>
#include <QString>
#include <QMainWindow>

class AppService;
class QLabel;
class QPushButton;
class QStackedWidget;

class MainWindow : public QMainWindow {
public:
    explicit MainWindow(AppService *storageService,
                        const QString &statusMessage,
                        std::function<void(QWidget *)> openConnectionSettings,
                        QWidget *parent = nullptr);
    ~MainWindow() override;

private:
    void applyTheme();
    void buildUi();
    void setCurrentPage(int index);
    void updateNavigationState();

    AppService *m_storageService = nullptr;
    QLabel *m_pageTitleLabel = nullptr;
    QLabel *m_pageSubtitleLabel = nullptr;
    QPushButton *m_inventoryButton = nullptr;
    QPushButton *m_reimbursementButton = nullptr;
    QStackedWidget *m_stack = nullptr;
    QString m_statusMessage;
    std::function<void(QWidget *)> m_openConnectionSettings;
};