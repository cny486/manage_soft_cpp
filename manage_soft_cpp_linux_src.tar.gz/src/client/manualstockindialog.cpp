#include "manualstockindialog.h"

#include "inventoryitempickerdialog.h"
#include "inventorytransactiondialog.h"
#include "recorddialog.h"

#include <QDate>
#include <QDialogButtonBox>
#include <QHeaderView>
#include <QLabel>
#include <QMessageBox>
#include <QPushButton>
#include <QTableWidget>
#include <QTableWidgetItem>
#include <QVBoxLayout>

namespace {
QString inventoryRecordSummary(const QVariantMap &record)
{
    const QString uniqueId = record.value(QStringLiteral("uniqueId")).toString().trimmed();
    const QString manufacturerPart = record.value(QStringLiteral("manufacturerPart")).toString().trimmed();
    const QString manufacturer = record.value(QStringLiteral("manufacturer")).toString().trimmed();
    const QString name = record.value(QStringLiteral("name")).toString().trimmed();

    QStringList parts;
    if (!uniqueId.isEmpty()) {
        parts.append(uniqueId);
    }
    if (!manufacturerPart.isEmpty()) {
        parts.append(manufacturerPart);
    }
    if (!manufacturer.isEmpty()) {
        parts.append(manufacturer);
    }
    if (!name.isEmpty()) {
        parts.append(name);
    }

    return parts.join(QStringLiteral(" / "));
}

QList<FieldDefinition> stockEntryDialogFields(const QList<FieldDefinition> &fields)
{
    return prioritizedFields(fields,
                             {
                                 QStringLiteral("manufacturerPart"),
                                 QStringLiteral("quantity"),
                                 QStringLiteral("location"),
                                 QStringLiteral("date")
                             },
                             {
                                 QStringLiteral("manufacturerPart"),
                                 QStringLiteral("quantity"),
                                 QStringLiteral("location"),
                                 QStringLiteral("date")
                             });
}
}

ManualStockInDialog::ManualStockInDialog(const QList<FieldDefinition> &fields,
                                         const QList<QVariantMap> &inventoryRecords,
                                         QWidget *parent)
    : QDialog(parent),
      m_fields(fields),
      m_inventoryRecords(inventoryRecords)
{
    setWindowTitle(QStringLiteral("手动入库"));
    resize(920, 560);

    auto *rootLayout = new QVBoxLayout(this);
    auto *descriptionLabel = new QLabel(QStringLiteral("可连续添加多条入库项目。已有物料会追加库存，新物料会按录入信息新建库存记录。"), this);
    descriptionLabel->setWordWrap(true);

    auto *buttonLayout = new QHBoxLayout();
    auto *addExistingButton = new QPushButton(QStringLiteral("选择已有物料"), this);
    auto *addNewButton = new QPushButton(QStringLiteral("新增入库项目"), this);
    auto *removeButton = new QPushButton(QStringLiteral("删除所选"), this);

    connect(addExistingButton, &QPushButton::clicked, this, &ManualStockInDialog::addExistingItem);
    connect(addNewButton, &QPushButton::clicked, this, &ManualStockInDialog::addNewItem);
    connect(removeButton, &QPushButton::clicked, this, &ManualStockInDialog::removeSelectedEntry);

    buttonLayout->addWidget(addExistingButton);
    buttonLayout->addWidget(addNewButton);
    buttonLayout->addWidget(removeButton);
    buttonLayout->addStretch();

    m_table = new QTableWidget(this);
    m_table->setColumnCount(5);
    m_table->setHorizontalHeaderLabels({
        QStringLiteral("类型"),
        QStringLiteral("物料"),
        QStringLiteral("入库数量"),
        QStringLiteral("业务日期"),
        QStringLiteral("备注")
    });
    m_table->setSelectionBehavior(QAbstractItemView::SelectRows);
    m_table->setSelectionMode(QAbstractItemView::SingleSelection);
    m_table->setEditTriggers(QAbstractItemView::NoEditTriggers);
    m_table->horizontalHeader()->setStretchLastSection(true);
    m_table->horizontalHeader()->setSectionResizeMode(1, QHeaderView::Stretch);
    m_table->verticalHeader()->setVisible(false);

    auto *buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, this);
    connect(buttonBox, &QDialogButtonBox::accepted, this, &ManualStockInDialog::accept);
    connect(buttonBox, &QDialogButtonBox::rejected, this, &ManualStockInDialog::reject);

    rootLayout->addWidget(descriptionLabel);
    rootLayout->addLayout(buttonLayout);
    rootLayout->addWidget(m_table, 1);
    rootLayout->addWidget(buttonBox);

    refreshTable();
}

QList<ManualStockInEntry> ManualStockInDialog::entries() const
{
    return m_entries;
}

void ManualStockInDialog::accept()
{
    if (m_entries.isEmpty()) {
        QMessageBox::information(this,
                                 QStringLiteral("提示"),
                                 QStringLiteral("请至少添加一条入库项目。"));
        return;
    }

    QDialog::accept();
}

void ManualStockInDialog::addExistingItem()
{
    InventoryItemPickerDialog picker(m_inventoryRecords, this);
    if (picker.exec() != QDialog::Accepted) {
        return;
    }

    const QVariantMap record = picker.selectedRecord();
    if (record.isEmpty()) {
        return;
    }

    InventoryTransactionDialog transactionDialog(InventoryTransactionDialog::Mode::StockIn,
                                                 inventoryRecordSummary(record),
                                                 record.value(QStringLiteral("quantity")).toInt(),
                                                 this);
    if (transactionDialog.exec() != QDialog::Accepted) {
        return;
    }

    ManualStockInEntry entry;
    entry.existingItem = true;
    entry.summary = inventoryRecordSummary(record);
    entry.note = transactionDialog.note();
    entry.itemData.insert(QStringLiteral("id"), record.value(QStringLiteral("id")));
    entry.itemData.insert(QStringLiteral("quantity"), transactionDialog.quantity());
    entry.itemData.insert(QStringLiteral("date"), transactionDialog.transactionDate());
    m_entries.append(entry);
    refreshTable();
}

void ManualStockInDialog::addNewItem()
{
    RecordDialog dialog(QStringLiteral("新增入库项目"), stockEntryDialogFields(m_fields), this);

    QVariantMap defaultRecord;
    defaultRecord.insert(QStringLiteral("quantity"), 1);
    defaultRecord.insert(QStringLiteral("date"), QDate::currentDate().toString(Qt::ISODate));
    dialog.setRecordData(defaultRecord);

    if (dialog.exec() != QDialog::Accepted) {
        return;
    }

    ManualStockInEntry entry;
    entry.existingItem = false;
    entry.itemData = dialog.recordData();
    entry.note = entry.itemData.value(QStringLiteral("comment")).toString().trimmed();
    entry.summary = inventoryRecordSummary(entry.itemData);
    m_entries.append(entry);
    refreshTable();
}

void ManualStockInDialog::removeSelectedEntry()
{
    const int currentRow = m_table->currentRow();
    if (currentRow < 0 || currentRow >= m_entries.size()) {
        QMessageBox::information(this,
                                 QStringLiteral("提示"),
                                 QStringLiteral("请先选择要删除的入库项目。"));
        return;
    }

    m_entries.removeAt(currentRow);
    refreshTable();
}

void ManualStockInDialog::refreshTable()
{
    m_table->setRowCount(m_entries.size());
    for (int row = 0; row < m_entries.size(); ++row) {
        const ManualStockInEntry &entry = m_entries.at(row);
        m_table->setItem(row, 0, new QTableWidgetItem(entry.existingItem ? QStringLiteral("已有物料")
                                                                          : QStringLiteral("新物料")));
        m_table->setItem(row, 1, new QTableWidgetItem(entry.summary));
        m_table->setItem(row, 2, new QTableWidgetItem(entry.itemData.value(QStringLiteral("quantity")).toString()));
        m_table->setItem(row, 3, new QTableWidgetItem(entry.itemData.value(QStringLiteral("date")).toString()));
        m_table->setItem(row, 4, new QTableWidgetItem(entry.note));
    }
}