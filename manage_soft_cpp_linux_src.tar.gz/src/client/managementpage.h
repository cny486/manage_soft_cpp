#pragma once

#include "appschema.h"

#include <QList>
#include <QPoint>
#include <QVariantMap>
#include <QWidget>

class AppService;
class QLabel;
class QLineEdit;
class QPushButton;
class QComboBox;
class QTableWidget;
class QTableWidgetItem;

class ManagementPage : public QWidget {
public:
    ManagementPage(const PageConfig &config,
                   AppService *storageService,
                   QWidget *parent = nullptr);

    void reloadRecords();

private:
    bool isInventoryPage() const;
    bool isReimbursementPage() const;
    void buildUi();
    void refreshTable(const QList<QVariantMap> &records);
    void configureTableColumns();
    QList<FieldDefinition> listFields() const;
    QList<QVariantMap> filteredRecords(const QList<QVariantMap> &allRecords,
                                       const QString &keyword,
                                       const QString &category) const;
    void updateReimbursementSummary(const QList<QVariantMap> &allRecords);
    void updateCategoryFilterOptions(const QList<QVariantMap> &allRecords);
    QVariantMap selectedRecord() const;
    QList<QVariantMap> checkedRecords() const;
    void showInventoryContextMenu(const QPoint &position);
    void viewInventoryHistory(const QString &inputTypeFilter = QString());
    void directUpdateRecord();
    void stockInRecord();
    void manualStockInRecord();
    void excelStockInRecord();
    void fulfillDemandRecord();
    void stockOutRecord();
    void manualStockOutRecord();
    void bomStockOutRecord();
    void importInventoryRecords(InventoryOperationType operationType);
    void addRecord();
    void editRecord();
    void deleteRecord();
    void toggleBatchMode();
    void deleteCheckedRecords();
    void saveSelectedAttachments();
    void downloadInvoiceAttachment(int row);
    void importRecords();
    void exportRecords();

    PageConfig m_config;
    AppService *m_storageService = nullptr;
    QLineEdit *m_searchEdit = nullptr;
    QComboBox *m_categoryFilterCombo = nullptr;
    QTableWidget *m_table = nullptr;
    QLabel *m_statusLabel = nullptr;
    QWidget *m_summaryPanel = nullptr;
    QLabel *m_uninvoicedAmountLabel = nullptr;
    QLabel *m_invoicedAmountLabel = nullptr;
    QLabel *m_unreimbursedAmountLabel = nullptr;
    QLabel *m_reimbursedAmountLabel = nullptr;
    QPushButton *m_batchModeButton = nullptr;
    QPushButton *m_batchDeleteButton = nullptr;
    QList<QVariantMap> m_visibleRecords;
    bool m_batchModeEnabled = false;
};