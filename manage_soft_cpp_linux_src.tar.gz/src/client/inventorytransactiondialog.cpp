#include "inventorytransactiondialog.h"

#include <QDate>
#include <QDateEdit>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QLabel>
#include <QMessageBox>
#include <QSpinBox>
#include <QTextEdit>
#include <QVBoxLayout>

InventoryTransactionDialog::InventoryTransactionDialog(Mode mode,
                                                       const QString &itemSummary,
                                                       int currentQuantity,
                                                       QWidget *parent)
    : QDialog(parent),
      m_mode(mode)
{
    setWindowTitle(mode == Mode::StockIn ? QStringLiteral("手动入库") : QStringLiteral("手动出库"));
    resize(480, 320);

    auto *rootLayout = new QVBoxLayout(this);
    auto *formLayout = new QFormLayout();
    formLayout->setLabelAlignment(Qt::AlignRight);
    formLayout->setSpacing(12);

    m_itemLabel = new QLabel(itemSummary, this);
    m_itemLabel->setWordWrap(true);
    m_currentQuantityLabel = new QLabel(QString::number(currentQuantity), this);

    m_quantitySpinBox = new QSpinBox(this);
    m_quantitySpinBox->setRange(1, 1000000000);
    m_quantitySpinBox->setValue(1);

    m_dateEdit = new QDateEdit(QDate::currentDate(), this);
    m_dateEdit->setCalendarPopup(true);
    m_dateEdit->setDisplayFormat(QStringLiteral("yyyy-MM-dd"));

    m_noteEdit = new QTextEdit(this);
    m_noteEdit->setMinimumHeight(90);

    formLayout->addRow(QStringLiteral("物料："), m_itemLabel);
    formLayout->addRow(QStringLiteral("当前库存："), m_currentQuantityLabel);
    formLayout->addRow(mode == Mode::StockIn ? QStringLiteral("入库数量：") : QStringLiteral("出库数量："), m_quantitySpinBox);
    formLayout->addRow(QStringLiteral("业务日期："), m_dateEdit);
    formLayout->addRow(QStringLiteral("备注："), m_noteEdit);

    auto *buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, this);
    connect(buttonBox, &QDialogButtonBox::accepted, this, &InventoryTransactionDialog::accept);
    connect(buttonBox, &QDialogButtonBox::rejected, this, &InventoryTransactionDialog::reject);

    rootLayout->addLayout(formLayout);
    rootLayout->addWidget(buttonBox);
}

int InventoryTransactionDialog::quantity() const
{
    return m_quantitySpinBox->value();
}

QString InventoryTransactionDialog::transactionDate() const
{
    return m_dateEdit->date().toString(Qt::ISODate);
}

QString InventoryTransactionDialog::note() const
{
    return m_noteEdit->toPlainText().trimmed();
}

void InventoryTransactionDialog::accept()
{
    if (m_quantitySpinBox->value() <= 0) {
        QMessageBox::warning(this,
                             QStringLiteral("数量无效"),
                             QStringLiteral("变更数量必须大于 0。"));
        return;
    }

    QDialog::accept();
}