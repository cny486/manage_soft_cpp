#include "managementpage.h"

#include "appservice.h"
#include "inventoryhistorydialog.h"
#include "inventoryfulfillmentdialog.h"
#include "manualstockindialog.h"
#include "inventoryitempickerdialog.h"
#include "inventoryrecorddialog.h"
#include "inventorytransactiondialog.h"

#include "recorddialog.h"

#include <QDate>
#include <QDialog>
#include <QFileDialog>
#include <QFileInfo>
#include <QFrame>
#include <QGridLayout>
#include <QHeaderView>
#include <QHBoxLayout>
#include <QInputDialog>
#include <QLabel>
#include <QLineEdit>
#include <QMenu>
#include <QMessageBox>
#include <QObject>
#include <QPushButton>
#include <QComboBox>
#include <QRegularExpression>
#include <QSignalBlocker>
#include <QTableWidget>
#include <QTableWidgetItem>
#include <QToolButton>
#include <QVBoxLayout>

namespace {
enum class InventoryActionModeSelection {
    Cancel,
    Manual,
    Bom
};

QString displayAttachmentName(const QString &reference);

QString uniqueFilePath(const QString &directoryPath, const QString &fileName);

QStringList splitAttachmentReferences(const QVariant &value)
{
    return value.toString().split(QChar('\n'), Qt::SkipEmptyParts);
}

QString displayDateValue(const QString &rawValue)
{
    const QString trimmed = rawValue.trimmed();
    const QDate isoDate = QDate::fromString(trimmed, Qt::ISODate);
    if (isoDate.isValid()) {
        return isoDate.toString(Qt::ISODate);
    }

    bool ok = false;
    const int serial = trimmed.toInt(&ok);
    if (!ok || serial <= 0) {
        return trimmed;
    }

    const QDate excelEpoch(1899, 12, 30);
    const QDate converted = excelEpoch.addDays(serial);
    return converted.isValid() ? converted.toString(Qt::ISODate) : trimmed;
}

QString recordValueText(const QVariantMap &record, const FieldDefinition &field)
{
    if (field.type == FieldType::Date) {
        return displayDateValue(record.value(field.key).toString());
    }

    if (field.type == FieldType::Double) {
        return QString::number(record.value(field.key).toDouble(), 'f', 2);
    }

    if (field.type == FieldType::Boolean) {
        return record.value(field.key).toBool() ? QStringLiteral("是") : QStringLiteral("否");
    }

    if (field.type == FieldType::File || field.type == FieldType::Files) {
        const QString rawValue = record.value(field.key).toString().trimmed();
        if (rawValue.isEmpty()) {
            return QString();
        }

        QStringList displayNames;
        const QStringList paths = rawValue.split(QChar('\n'), Qt::SkipEmptyParts);
        for (const QString &path : paths) {
            const QString trimmedPath = path.trimmed();
            const QString displayName = displayAttachmentName(trimmedPath);
            displayNames.append(displayName.isEmpty() ? trimmedPath : displayName);
        }
        return displayNames.join(QStringLiteral(" | "));
    }

    return record.value(field.key).toString();
}

bool variantBoolValue(const QVariant &value)
{
    if (value.type() == QVariant::Bool) {
        return value.toBool();
    }

    const QString text = value.toString().trimmed().toLower();
    return text == QStringLiteral("true")
           || text == QStringLiteral("1")
           || text == QStringLiteral("yes")
           || text == QStringLiteral("y")
           || text == QStringLiteral("是")
           || text == QStringLiteral("已开票")
           || text == QStringLiteral("已报账");
}

double recordAmountValue(const QVariantMap &record)
{
    bool ok = false;
    const double value = record.value(QStringLiteral("amount")).toString().toDouble(&ok);
    return ok ? value : record.value(QStringLiteral("amount")).toDouble();
}

QString amountText(double value)
{
    return QStringLiteral("%1 元").arg(QString::number(value, 'f', 2));
}

QString displayAttachmentName(const QString &reference)
{
    const QString fileName = QFileInfo(reference).fileName();
    const QRegularExpression archivedNamePattern(QStringLiteral("^[0-9a-fA-F]{32}_(.+)$"));
    const QRegularExpressionMatch match = archivedNamePattern.match(fileName);
    return match.hasMatch() ? match.captured(1) : fileName;
}

QString uniqueFilePath(const QString &directoryPath, const QString &fileName)
{
    QFileInfo info(fileName);
    const QString completeBaseName = info.completeBaseName();
    const QString suffix = info.suffix();
    QString candidate = QDir(directoryPath).filePath(fileName);
    int counter = 2;
    while (QFileInfo::exists(candidate)) {
        const QString numberedName = suffix.isEmpty()
                                         ? QStringLiteral("%1 (%2)").arg(completeBaseName).arg(counter)
                                         : QStringLiteral("%1 (%2).%3").arg(completeBaseName).arg(counter).arg(suffix);
        candidate = QDir(directoryPath).filePath(numberedName);
        ++counter;
    }
    return candidate;
}

QString inventoryRecordSummary(const QVariantMap &record)
{
    const QString uniqueId = record.value(QStringLiteral("uniqueId")).toString().trimmed();
    const QString manufacturerPart = record.value(QStringLiteral("manufacturerPart")).toString().trimmed();
    const QString manufacturer = record.value(QStringLiteral("manufacturer")).toString().trimmed();
    const QString name = record.value(QStringLiteral("name")).toString().trimmed();

    QStringList parts;
    if (!uniqueId.isEmpty()) {
        parts.append(uniqueId);
    }
    if (!manufacturerPart.isEmpty()) {
        parts.append(manufacturerPart);
    }
    if (!manufacturer.isEmpty()) {
        parts.append(manufacturer);
    }
    if (!name.isEmpty()) {
        parts.append(name);
    }

    return parts.join(QStringLiteral(" / "));
}

QString sectionPanelStyle()
{
    return QStringLiteral(
    "#sectionPanel { background-color: #fbfdfd; border: 1px solid #dde8e9; border-radius: 24px; }"
        "QLabel[role='sectionTitle'] { color: #173137; font-size: 16px; font-weight: 800; }"
        "QLabel[role='sectionHint'] { color: #71888c; font-size: 12px; font-weight: 500; }");
}

QString summaryPanelStyle()
{
    return QStringLiteral(
    "#summaryPanel { background-color: #fbfdfd; border: 1px solid #dde8e9; border-radius: 24px; }"
        "QLabel[role='sectionTitle'] { color: #173137; font-size: 16px; font-weight: 800; }"
        "QLabel[role='sectionHint'] { color: #71888c; font-size: 12px; font-weight: 500; }"
        "QLabel[role='caption'] { color: #739094; font-size: 12px; font-weight: 700; }"
        "QLabel[role='amount'] { color: #173137; font-size: 24px; font-weight: 800; }");
}

QString summaryCardStyle()
{
    return QStringLiteral(
    "#summaryCard { background-color: #f7fbfb; border: 1px solid #e1ebec; border-radius: 18px; }");
}

QString menuStyle()
{
    return QStringLiteral(
        "QMenu { background-color: #fbfdfd; color: #1d3135; border: 1px solid #d7e3e5; padding: 8px; border-radius: 14px; }"
        "QMenu::item { padding: 8px 18px; border-radius: 8px; }"
        "QMenu::item:selected { background-color: #edf5f5; }");
}

QString modalStyle()
{
    return QStringLiteral(
        "QDialog { background-color: #f4f7f8; }"
        "QLabel { color: #1d3135; }");
}

void setButtonVariant(QPushButton *button, const QString &variant)
{
    if (button != nullptr) {
        button->setProperty("variant", variant);
    }
}

QList<FieldDefinition> stockEditDialogFields(const QList<FieldDefinition> &fields)
{
    return prioritizedFields(fields,
                             {
                                 QStringLiteral("manufacturerPart"),
                                 QStringLiteral("quantity"),
                                 QStringLiteral("location"),
                                 QStringLiteral("date")
                             },
                             {
                                 QStringLiteral("manufacturerPart"),
                                 QStringLiteral("quantity"),
                                 QStringLiteral("location"),
                                 QStringLiteral("date")
                             });
}

QToolButton *createOverflowMenuButton(QMenu *menu, QWidget *parent)
{
    auto *button = new QToolButton(parent);
    button->setText(QStringLiteral("..."));
    button->setToolButtonStyle(Qt::ToolButtonTextOnly);
    button->setPopupMode(QToolButton::InstantPopup);
    button->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
    button->setFixedSize(52, 40);
    button->setCursor(Qt::PointingHandCursor);
    button->setStyleSheet(QStringLiteral(
        "QToolButton {"
        "  background-color: #f7fbfb;"
        "  color: #557075;"
        "  border: 1px solid #dce7e8;"
        "  border-radius: 14px;"
        "  padding: 0px;"
        "  text-align: center;"
        "  font-size: 22px;"
        "  font-weight: 700;"
        "}"
        "QToolButton:hover { background-color: #eef6f6; border-color: #c8d9db; }"
        "QToolButton:pressed { background-color: #e4efef; }"
        "QToolButton::menu-indicator { image: none; width: 0px; }"));

    button->setMenu(menu);
    return button;
}

InventoryActionModeSelection selectInventoryActionMode(QWidget *parent,
                                                      const QString &windowTitle,
                                                      const QString &titleText,
                                                      const QString &hintText,
                                                      const QString &manualButtonText,
                                                      const QString &bomButtonText)
{
    QDialog dialog(parent);
    dialog.setWindowTitle(windowTitle);
    dialog.resize(420, 220);
    dialog.setStyleSheet(modalStyle());

    auto *layout = new QVBoxLayout(&dialog);
    layout->setContentsMargins(20, 20, 20, 20);
    layout->setSpacing(10);
    auto *titleLabel = new QLabel(titleText, &dialog);
    titleLabel->setStyleSheet(QStringLiteral("font-size: 20px; font-weight: 800; color: #173137;"));
    auto *hintLabel = new QLabel(hintText, &dialog);
    hintLabel->setWordWrap(true);
    hintLabel->setStyleSheet(QStringLiteral("color: #71888c;"));

    auto *manualButton = new QPushButton(manualButtonText, &dialog);
    auto *bomButton = new QPushButton(bomButtonText, &dialog);
    auto *cancelButton = new QPushButton(QStringLiteral("取消"), &dialog);
    setButtonVariant(manualButton, QStringLiteral("primary"));
    setButtonVariant(bomButton, QStringLiteral("subtle"));
    setButtonVariant(cancelButton, QStringLiteral("subtle"));
    manualButton->setMinimumHeight(44);
    bomButton->setMinimumHeight(44);
    cancelButton->setMinimumHeight(40);

    QObject::connect(manualButton, &QPushButton::clicked, &dialog, [&dialog]() { dialog.done(1); });
    QObject::connect(bomButton, &QPushButton::clicked, &dialog, [&dialog]() { dialog.done(2); });
    QObject::connect(cancelButton, &QPushButton::clicked, &dialog, &QDialog::reject);

    layout->addWidget(titleLabel);
    layout->addWidget(hintLabel);
    layout->addSpacing(8);
    layout->addWidget(manualButton);
    layout->addWidget(bomButton);
    layout->addStretch();
    layout->addWidget(cancelButton);

    const int result = dialog.exec();
    if (result == 1) {
        return InventoryActionModeSelection::Manual;
    }
    if (result == 2) {
        return InventoryActionModeSelection::Bom;
    }
    return InventoryActionModeSelection::Cancel;
}

QList<QVariantMap> filteredHistoryRecords(const QList<QVariantMap> &records, const QString &inputTypeFilter)
{
    if (inputTypeFilter.trimmed().isEmpty()) {
        return records;
    }

    QList<QVariantMap> filtered;
    for (const QVariantMap &record : records) {
        if (record.value(QStringLiteral("inputType")).toString() == inputTypeFilter) {
            filtered.append(record);
        }
    }
    return filtered;
}

void showImportResultMessage(QWidget *parent, bool success, const QString &message)
{
    if (message.trimmed().isEmpty()) {
        QMessageBox::information(parent,
                                 QStringLiteral("导入完成"),
                                 QStringLiteral("Excel 已导入。"));
        return;
    }

    const QStringList lines = message.split(QChar('\n'));
    const QString summary = lines.isEmpty() ? message : lines.first();
    const QString details = lines.size() > 1 ? lines.mid(1).join(QStringLiteral("\n")).trimmed() : QString();

    QMessageBox box(parent);
    box.setIcon(success ? QMessageBox::Information : QMessageBox::Warning);
    box.setWindowTitle(success ? QStringLiteral("导入完成") : QStringLiteral("导入失败"));
    box.setText(summary);
    if (!details.isEmpty()) {
        box.setDetailedText(details);
        box.setInformativeText(QStringLiteral("可展开查看具体行失败明细。"));
    }
    box.exec();
}

QStringList inventoryCategories(const QList<QVariantMap> &records)
{
    QStringList categories;
    for (const QVariantMap &record : records) {
        const QString category = record.value(QStringLiteral("category")).toString().trimmed();
        if (!category.isEmpty() && !categories.contains(category, Qt::CaseInsensitive)) {
            categories.append(category);
        }
    }

    categories.sort(Qt::CaseInsensitive);
    return categories;
}
}

ManagementPage::ManagementPage(const PageConfig &config,
                               AppService *storageService,
                               QWidget *parent)
    : QWidget(parent),
      m_config(config),
      m_storageService(storageService)
{
    buildUi();
    reloadRecords();
}

void ManagementPage::reloadRecords()
{
    const QList<QVariantMap> allRecords = m_storageService->loadPageRecords(m_config.pageId);
    if (isInventoryPage()) {
        updateCategoryFilterOptions(allRecords);
    }
    if (isReimbursementPage()) {
        updateReimbursementSummary(allRecords);
    }

    const QString category = m_categoryFilterCombo == nullptr
                                 ? QString()
                                 : m_categoryFilterCombo->currentData().toString();
    refreshTable(filteredRecords(allRecords, m_searchEdit->text().trimmed(), category));
}

bool ManagementPage::isInventoryPage() const
{
    return m_config.pageId == QStringLiteral("inventory");
}

bool ManagementPage::isReimbursementPage() const
{
    return m_config.pageId == QStringLiteral("reimbursement");
}

void ManagementPage::updateReimbursementSummary(const QList<QVariantMap> &records)
{
    if (!isReimbursementPage()) {
        return;
    }

    double uninvoicedAmount = 0.0;
    double invoicedAmount = 0.0;
    double unreimbursedAmount = 0.0;
    double reimbursedAmount = 0.0;

    for (const QVariantMap &record : records) {
        const double amount = recordAmountValue(record);
        if (variantBoolValue(record.value(QStringLiteral("invoiceIssued")))) {
            invoicedAmount += amount;
        } else {
            uninvoicedAmount += amount;
        }

        if (variantBoolValue(record.value(QStringLiteral("reimbursed")))) {
            reimbursedAmount += amount;
        } else {
            unreimbursedAmount += amount;
        }
    }

    if (m_uninvoicedAmountLabel != nullptr) {
        m_uninvoicedAmountLabel->setText(amountText(uninvoicedAmount));
    }
    if (m_invoicedAmountLabel != nullptr) {
        m_invoicedAmountLabel->setText(amountText(invoicedAmount));
    }
    if (m_unreimbursedAmountLabel != nullptr) {
        m_unreimbursedAmountLabel->setText(amountText(unreimbursedAmount));
    }
    if (m_reimbursedAmountLabel != nullptr) {
        m_reimbursedAmountLabel->setText(amountText(reimbursedAmount));
    }
}

void ManagementPage::buildUi()
{
    auto *rootLayout = new QVBoxLayout(this);
    rootLayout->setContentsMargins(0, 0, 0, 0);
    rootLayout->setSpacing(16);

    if (isReimbursementPage()) {
        auto *summaryPanel = new QFrame(this);
        summaryPanel->setObjectName(QStringLiteral("summaryPanel"));
        summaryPanel->setStyleSheet(summaryPanelStyle());
        auto *summaryLayout = new QGridLayout(summaryPanel);
        summaryLayout->setContentsMargins(20, 20, 20, 20);
        summaryLayout->setHorizontalSpacing(14);
        summaryLayout->setVerticalSpacing(14);

        auto *summaryTitleLabel = new QLabel(QStringLiteral("费用概览"), summaryPanel);
        summaryTitleLabel->setProperty("role", QStringLiteral("sectionTitle"));
        auto *summaryHintLabel = new QLabel(QStringLiteral("按开票与报账状态快速查看资金分布。"), summaryPanel);
        summaryHintLabel->setProperty("role", QStringLiteral("sectionHint"));
        summaryLayout->addWidget(summaryTitleLabel, 0, 0, 1, 2);
        summaryLayout->addWidget(summaryHintLabel, 1, 0, 1, 2);

        auto createSummaryCard = [summaryPanel, summaryLayout](const QString &title,
                                                               int row,
                                                               int column,
                                                               QLabel **amountLabel) {
            auto *card = new QFrame(summaryPanel);
            card->setObjectName(QStringLiteral("summaryCard"));
            card->setStyleSheet(summaryCardStyle());
            auto *cardLayout = new QVBoxLayout(card);
            cardLayout->setContentsMargins(16, 16, 16, 16);
            cardLayout->setSpacing(6);

            auto *titleLabel = new QLabel(title, card);
            titleLabel->setProperty("role", QStringLiteral("caption"));
            auto *valueLabel = new QLabel(amountText(0.0), card);
            valueLabel->setProperty("role", QStringLiteral("amount"));

            cardLayout->addWidget(titleLabel);
            cardLayout->addWidget(valueLabel);
            cardLayout->addStretch();
            summaryLayout->addWidget(card, row, column);
            *amountLabel = valueLabel;
        };

        createSummaryCard(QStringLiteral("未开票金额"), 2, 0, &m_uninvoicedAmountLabel);
        createSummaryCard(QStringLiteral("已开票金额"), 2, 1, &m_invoicedAmountLabel);
        createSummaryCard(QStringLiteral("未报账金额"), 3, 0, &m_unreimbursedAmountLabel);
        createSummaryCard(QStringLiteral("已报账金额"), 3, 1, &m_reimbursedAmountLabel);

        m_summaryPanel = summaryPanel;
        rootLayout->addWidget(m_summaryPanel);
    }

    auto *filterLayout = new QHBoxLayout();
    filterLayout->setSpacing(10);
    auto *filterLabel = new QLabel(QStringLiteral("搜索："), this);
    filterLabel->setStyleSheet(QStringLiteral("color: #70888c; font-size: 13px; font-weight: 700;"));
    m_searchEdit = new QLineEdit(this);
    m_searchEdit->setPlaceholderText(QStringLiteral("输入关键字"));
    m_searchEdit->setMinimumHeight(42);
    auto *categoryLabel = new QLabel(QStringLiteral("种类："), this);
    categoryLabel->setStyleSheet(QStringLiteral("color: #70888c; font-size: 13px; font-weight: 700;"));
    m_categoryFilterCombo = new QComboBox(this);
    m_categoryFilterCombo->setMinimumHeight(42);
    m_categoryFilterCombo->setVisible(isInventoryPage());
    auto *searchButton = new QPushButton(QStringLiteral("查询"), this);
    auto *resetButton = new QPushButton(QStringLiteral("重置"), this);
    setButtonVariant(searchButton, QStringLiteral("primary"));
    setButtonVariant(resetButton, QStringLiteral("subtle"));
    searchButton->setMinimumHeight(42);
    resetButton->setMinimumHeight(42);
    connect(searchButton, &QPushButton::clicked, this, [this]() { reloadRecords(); });
    connect(resetButton, &QPushButton::clicked, this, [this]() {
        m_searchEdit->clear();
        if (m_categoryFilterCombo != nullptr) {
            m_categoryFilterCombo->setCurrentIndex(0);
        }
        reloadRecords();
    });
    if (isInventoryPage()) {
        connect(m_categoryFilterCombo,
                QOverload<int>::of(&QComboBox::currentIndexChanged),
                this,
                [this](int) { reloadRecords(); });
    }

    filterLayout->addWidget(filterLabel);
    filterLayout->addWidget(m_searchEdit, 1);
    if (isInventoryPage()) {
        filterLayout->addWidget(categoryLabel);
        filterLayout->addWidget(m_categoryFilterCombo);
    }
    filterLayout->addWidget(searchButton);
    filterLayout->addWidget(resetButton);

    auto *actionWrapperLayout = new QVBoxLayout();
    actionWrapperLayout->setContentsMargins(0, 0, 0, 0);
    actionWrapperLayout->setSpacing(8);

    if (isInventoryPage()) {
        auto *manualLayout = new QHBoxLayout();
        manualLayout->setSpacing(10);

        auto *overflowMenu = new QMenu(this);
        overflowMenu->setStyleSheet(menuStyle());

        auto *directMenu = overflowMenu->addMenu(QStringLiteral("直接修改"));
        QAction *manualDirectAction = directMenu->addAction(QStringLiteral("手动"));
        QAction *excelDirectAction = directMenu->addAction(QStringLiteral("Excel"));

        auto *historyMenu = overflowMenu->addMenu(QStringLiteral("历史记录"));
        QAction *allHistoryAction = historyMenu->addAction(QStringLiteral("全部"));
        QAction *manualHistoryAction = historyMenu->addAction(QStringLiteral("手动"));
        QAction *excelHistoryAction = historyMenu->addAction(QStringLiteral("Excel"));

        auto *stockInButton = new QPushButton(QStringLiteral("入库"), this);
        auto *addButton = new QPushButton(QStringLiteral("新增"), this);
        auto *editButton = new QPushButton(QStringLiteral("编辑"), this);
        m_batchModeButton = new QPushButton(QStringLiteral("批量操作"), this);
        m_batchDeleteButton = new QPushButton(QStringLiteral("批量删除"), this);
        auto *fulfillmentButton = new QPushButton(QStringLiteral("配单"), this);
        auto *stockOutButton = new QPushButton(QStringLiteral("出库"), this);
        auto *exportButton = new QPushButton(QStringLiteral("导出 Excel"), this);
        auto *refreshButton = new QPushButton(QStringLiteral("刷新"), this);

        setButtonVariant(stockInButton, QStringLiteral("primary"));
        setButtonVariant(addButton, QStringLiteral("primary"));
        setButtonVariant(editButton, QStringLiteral("subtle"));
        setButtonVariant(m_batchModeButton, QStringLiteral("subtle"));
        setButtonVariant(m_batchDeleteButton, QStringLiteral("danger"));
        setButtonVariant(fulfillmentButton, QStringLiteral("subtle"));
        setButtonVariant(stockOutButton, QStringLiteral("subtle"));
        setButtonVariant(exportButton, QStringLiteral("subtle"));
        setButtonVariant(refreshButton, QStringLiteral("subtle"));

        m_batchModeButton->setCheckable(true);
        m_batchDeleteButton->hide();

        connect(manualDirectAction, &QAction::triggered, this, [this]() { directUpdateRecord(); });
        connect(excelDirectAction, &QAction::triggered, this, [this]() {
            importInventoryRecords(InventoryOperationType::DirectUpdate);
        });
        connect(stockInButton, &QPushButton::clicked, this, [this]() { stockInRecord(); });
        connect(addButton, &QPushButton::clicked, this, [this]() { addRecord(); });
        connect(editButton, &QPushButton::clicked, this, [this]() { editRecord(); });
        connect(m_batchModeButton, &QPushButton::clicked, this, [this]() { toggleBatchMode(); });
        connect(m_batchDeleteButton, &QPushButton::clicked, this, [this]() { deleteCheckedRecords(); });
        connect(fulfillmentButton, &QPushButton::clicked, this, [this]() { fulfillDemandRecord(); });
        connect(stockOutButton, &QPushButton::clicked, this, [this]() { stockOutRecord(); });
        connect(allHistoryAction, &QAction::triggered, this, [this]() { viewInventoryHistory(); });
        connect(manualHistoryAction, &QAction::triggered, this, [this]() {
            viewInventoryHistory(QStringLiteral("手动录入"));
        });
        connect(excelHistoryAction, &QAction::triggered, this, [this]() {
            viewInventoryHistory(QStringLiteral("Excel 导入"));
        });
        connect(exportButton, &QPushButton::clicked, this, [this]() { exportRecords(); });
        connect(refreshButton, &QPushButton::clicked, this, [this]() { reloadRecords(); });

        manualLayout->addWidget(createOverflowMenuButton(overflowMenu, this));
        manualLayout->addWidget(stockInButton);
        manualLayout->addWidget(addButton);
        manualLayout->addWidget(editButton);
        manualLayout->addWidget(m_batchModeButton);
        manualLayout->addWidget(m_batchDeleteButton);
        manualLayout->addWidget(fulfillmentButton);
        manualLayout->addWidget(stockOutButton);
        manualLayout->addWidget(exportButton);
        manualLayout->addWidget(refreshButton);
        manualLayout->addStretch();

        actionWrapperLayout->addLayout(manualLayout);
    } else {
        auto *actionLayout = new QHBoxLayout();
        auto *addButton = new QPushButton(QStringLiteral("新增"), this);
        auto *editButton = new QPushButton(QStringLiteral("编辑"), this);
        auto *deleteButton = new QPushButton(QStringLiteral("删除"), this);
        QPushButton *saveAttachmentsButton = nullptr;
        auto *importButton = new QPushButton(QStringLiteral("导入 Excel"), this);
        auto *exportButton = new QPushButton(QStringLiteral("导出 Excel"), this);
        auto *refreshButton = new QPushButton(QStringLiteral("刷新"), this);

        setButtonVariant(addButton, QStringLiteral("primary"));
        setButtonVariant(editButton, QStringLiteral("subtle"));
        setButtonVariant(deleteButton, QStringLiteral("danger"));
        setButtonVariant(importButton, QStringLiteral("primary"));
        setButtonVariant(exportButton, QStringLiteral("subtle"));
        setButtonVariant(refreshButton, QStringLiteral("subtle"));

        connect(addButton, &QPushButton::clicked, this, [this]() { addRecord(); });
        connect(editButton, &QPushButton::clicked, this, [this]() { editRecord(); });
        connect(deleteButton, &QPushButton::clicked, this, [this]() { deleteRecord(); });
        if (isReimbursementPage()) {
            saveAttachmentsButton = new QPushButton(QStringLiteral("另存附件"), this);
            setButtonVariant(saveAttachmentsButton, QStringLiteral("subtle"));
            connect(saveAttachmentsButton, &QPushButton::clicked, this, [this]() { saveSelectedAttachments(); });
        }
        connect(importButton, &QPushButton::clicked, this, [this]() { importRecords(); });
        connect(exportButton, &QPushButton::clicked, this, [this]() { exportRecords(); });
        connect(refreshButton, &QPushButton::clicked, this, [this]() { reloadRecords(); });

        actionLayout->addWidget(addButton);
        actionLayout->addWidget(editButton);
        actionLayout->addWidget(deleteButton);
        if (saveAttachmentsButton != nullptr) {
            actionLayout->addWidget(saveAttachmentsButton);
        }
        actionLayout->addWidget(importButton);
        actionLayout->addWidget(exportButton);
        actionLayout->addWidget(refreshButton);
        actionLayout->addStretch();
        actionWrapperLayout->addLayout(actionLayout);
    }

    m_table = new QTableWidget(this);
    configureTableColumns();
    m_table->setSelectionBehavior(QAbstractItemView::SelectRows);
    m_table->setSelectionMode(QAbstractItemView::SingleSelection);
    m_table->setEditTriggers(QAbstractItemView::NoEditTriggers);
    m_table->setAlternatingRowColors(true);
    m_table->setShowGrid(false);
    m_table->setFrameShape(QFrame::NoFrame);
    m_table->horizontalHeader()->setStretchLastSection(true);
    m_table->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    m_table->horizontalHeader()->setDefaultAlignment(Qt::AlignLeft | Qt::AlignVCenter);
    m_table->verticalHeader()->setVisible(false);
    if (isInventoryPage()) {
        m_table->setContextMenuPolicy(Qt::CustomContextMenu);
        connect(m_table, &QTableWidget::customContextMenuRequested, this, [this](const QPoint &position) {
            showInventoryContextMenu(position);
        });
    }
    connect(m_table, &QTableWidget::cellDoubleClicked, this, [this](int, int) {
        if (isInventoryPage()) {
            directUpdateRecord();
        } else {
            editRecord();
        }
    });

    m_statusLabel = new QLabel(this);

    auto *filterPanel = new QFrame(this);
    filterPanel->setObjectName(QStringLiteral("sectionPanel"));
    filterPanel->setStyleSheet(sectionPanelStyle());
    auto *filterPanelLayout = new QVBoxLayout(filterPanel);
    filterPanelLayout->setContentsMargins(18, 18, 18, 18);
    filterPanelLayout->setSpacing(10);
    auto *filterTitleLabel = new QLabel(QStringLiteral("检索与筛选"), filterPanel);
    filterTitleLabel->setProperty("role", QStringLiteral("sectionTitle"));
    auto *filterHintLabel = new QLabel(QStringLiteral("通过关键词与分类快速收敛结果。"), filterPanel);
    filterHintLabel->setProperty("role", QStringLiteral("sectionHint"));
    filterPanelLayout->addWidget(filterTitleLabel);
    filterPanelLayout->addWidget(filterHintLabel);
    filterPanelLayout->addLayout(filterLayout);

    auto *actionPanel = new QFrame(this);
    actionPanel->setObjectName(QStringLiteral("sectionPanel"));
    actionPanel->setStyleSheet(sectionPanelStyle());
    auto *actionPanelLayout = new QVBoxLayout(actionPanel);
    actionPanelLayout->setContentsMargins(18, 18, 18, 18);
    actionPanelLayout->setSpacing(10);
    auto *actionTitleLabel = new QLabel(QStringLiteral("快捷操作"), actionPanel);
    actionTitleLabel->setProperty("role", QStringLiteral("sectionTitle"));
    auto *actionHintLabel = new QLabel(isInventoryPage()
                                           ? QStringLiteral("聚合常用入库、配单、导出与批量维护操作。")
                                           : QStringLiteral("集中执行新增、编辑、导入导出与附件处理操作。"),
                                       actionPanel);
    actionHintLabel->setProperty("role", QStringLiteral("sectionHint"));
    actionPanelLayout->addWidget(actionTitleLabel);
    actionPanelLayout->addWidget(actionHintLabel);
    actionPanelLayout->addLayout(actionWrapperLayout);

    auto *tablePanel = new QFrame(this);
    tablePanel->setObjectName(QStringLiteral("sectionPanel"));
    tablePanel->setStyleSheet(sectionPanelStyle());
    auto *tablePanelLayout = new QVBoxLayout(tablePanel);
    tablePanelLayout->setContentsMargins(18, 18, 18, 14);
    tablePanelLayout->setSpacing(10);
    auto *tableTitleLabel = new QLabel(QStringLiteral("数据列表"), tablePanel);
    tableTitleLabel->setProperty("role", QStringLiteral("sectionTitle"));
    auto *tableHintLabel = new QLabel(QStringLiteral("更轻的表格视觉保留信息密度，同时突出选中与状态反馈。"), tablePanel);
    tableHintLabel->setProperty("role", QStringLiteral("sectionHint"));
    tablePanelLayout->addWidget(tableTitleLabel);
    tablePanelLayout->addWidget(tableHintLabel);
    tablePanelLayout->addWidget(m_table, 1);
    tablePanelLayout->addWidget(m_statusLabel);

    rootLayout->addWidget(filterPanel);
    rootLayout->addWidget(actionPanel);
    rootLayout->addWidget(tablePanel, 1);
}

void ManagementPage::refreshTable(const QList<QVariantMap> &records)
{
    m_visibleRecords = records;
    m_table->setRowCount(records.size());
    const QList<FieldDefinition> visibleFields = listFields();
    const int firstDataColumn = isInventoryPage() && m_batchModeEnabled ? 1 : 0;

    for (int row = 0; row < records.size(); ++row) {
        const QVariantMap &record = records.at(row);
        m_table->setRowHeight(row, 42);
        if (isInventoryPage() && m_batchModeEnabled) {
            auto *checkItem = new QTableWidgetItem();
            checkItem->setFlags(Qt::ItemIsEnabled | Qt::ItemIsSelectable | Qt::ItemIsUserCheckable);
            checkItem->setCheckState(Qt::Unchecked);
            checkItem->setData(Qt::UserRole, record.value("id").toString());
            m_table->setItem(row, 0, checkItem);
        }
        for (int column = 0; column < visibleFields.size(); ++column) {
            const FieldDefinition &field = visibleFields.at(column);
            const int tableColumn = column + firstDataColumn;
            if (isReimbursementPage() && field.key == QStringLiteral("invoiceAttachment")) {
                const QStringList references = splitAttachmentReferences(record.value(field.key));
                if (references.isEmpty()) {
                    auto *item = new QTableWidgetItem();
                    item->setTextAlignment(Qt::AlignLeft | Qt::AlignVCenter);
                    if (column == 0) {
                        item->setData(Qt::UserRole, record.value("id").toString());
                    }
                    m_table->setItem(row, tableColumn, item);
                } else {
                    const QString displayName = displayAttachmentName(references.constFirst().trimmed());
                    auto *button = new QPushButton(displayName.isEmpty() ? QStringLiteral("下载附件")
                                                                         : QStringLiteral("下载 %1").arg(displayName),
                                                   m_table);
                    setButtonVariant(button, QStringLiteral("subtle"));
                    button->setCursor(Qt::PointingHandCursor);
                    connect(button, &QPushButton::clicked, this, [this, row]() {
                        m_table->selectRow(row);
                        downloadInvoiceAttachment(row);
                    });
                    m_table->setCellWidget(row, tableColumn, button);

                    auto *item = new QTableWidgetItem(displayName);
                    item->setTextAlignment(Qt::AlignLeft | Qt::AlignVCenter);
                    if (column == 0) {
                        item->setData(Qt::UserRole, record.value("id").toString());
                    }
                    m_table->setItem(row, tableColumn, item);
                }
                continue;
            }

            auto *item = new QTableWidgetItem(recordValueText(record, field));
            item->setTextAlignment(Qt::AlignLeft | Qt::AlignVCenter);
            if (column == 0) {
                item->setData(Qt::UserRole, record.value("id").toString());
            }
            m_table->setItem(row, tableColumn, item);
        }
        if (m_config.showUpdatedAt) {
            auto *updatedAtItem = new QTableWidgetItem(record.value("updatedAt").toString());
            updatedAtItem->setTextAlignment(Qt::AlignLeft | Qt::AlignVCenter);
            m_table->setItem(row,
                             visibleFields.size() + firstDataColumn,
                             updatedAtItem);
        }
    }

    m_statusLabel->setText(QStringLiteral("当前共 %1 条记录，本地目录：%2")
                               .arg(records.size())
                               .arg(m_storageService->storageRoot()));
    m_statusLabel->setStyleSheet(QStringLiteral("color: #71888c; font-size: 12px; padding-top: 6px;"));
}

void ManagementPage::configureTableColumns()
{
    const QList<FieldDefinition> visibleFields = listFields();
    const bool includeBatchColumn = isInventoryPage() && m_batchModeEnabled;

    m_table->clearContents();
    m_table->setColumnCount(visibleFields.size() + (m_config.showUpdatedAt ? 1 : 0) + (includeBatchColumn ? 1 : 0));

    QStringList headers;
    if (includeBatchColumn) {
        headers.append(QStringLiteral("选择"));
    }
    for (const FieldDefinition &field : visibleFields) {
        headers.append(field.label);
    }
    if (m_config.showUpdatedAt) {
        headers.append(QStringLiteral("更新时间"));
    }
    m_table->setHorizontalHeaderLabels(headers);
    if (includeBatchColumn) {
        m_table->horizontalHeader()->setSectionResizeMode(0, QHeaderView::ResizeToContents);
    }
}

QList<FieldDefinition> ManagementPage::listFields() const
{
    if (m_config.listFieldKeys.isEmpty()) {
        return m_config.fields;
    }

    QList<FieldDefinition> fields;
    fields.reserve(m_config.listFieldKeys.size());
    for (const QString &key : m_config.listFieldKeys) {
        for (const FieldDefinition &field : m_config.fields) {
            if (field.key == key) {
                fields.append(field);
                break;
            }
        }
    }
    return fields;
}

QList<QVariantMap> ManagementPage::filteredRecords(const QList<QVariantMap> &allRecords,
                                                   const QString &keyword,
                                                   const QString &category) const
{
    QList<QVariantMap> matches;
    for (const QVariantMap &record : allRecords) {
        if (!category.isEmpty()
            && record.value(QStringLiteral("category")).toString().trimmed() != category) {
            continue;
        }

        if (keyword.isEmpty()) {
            matches.append(record);
            continue;
        }

        for (const QString &key : m_config.searchableKeys) {
            if (record.value(key).toString().contains(keyword, Qt::CaseInsensitive)) {
                matches.append(record);
                break;
            }
        }
    }
    return matches;
}

void ManagementPage::updateCategoryFilterOptions(const QList<QVariantMap> &allRecords)
{
    if (!isInventoryPage() || m_categoryFilterCombo == nullptr) {
        return;
    }

    const QString selectedCategory = m_categoryFilterCombo->currentData().toString();
    const QStringList categories = inventoryCategories(allRecords);
    const QSignalBlocker blocker(m_categoryFilterCombo);

    m_categoryFilterCombo->clear();
    m_categoryFilterCombo->addItem(QStringLiteral("全部种类"), QString());
    for (const QString &category : categories) {
        m_categoryFilterCombo->addItem(category, category);
    }

    const int selectedIndex = selectedCategory.isEmpty()
                                  ? 0
                                  : m_categoryFilterCombo->findData(selectedCategory);
    m_categoryFilterCombo->setCurrentIndex(selectedIndex >= 0 ? selectedIndex : 0);
}

QVariantMap ManagementPage::selectedRecord() const
{
    const int currentRow = m_table->currentRow();
    if (currentRow < 0 || currentRow >= m_visibleRecords.size()) {
        return {};
    }
    return m_visibleRecords.at(currentRow);
}

QList<QVariantMap> ManagementPage::checkedRecords() const
{
    QList<QVariantMap> records;
    if (!isInventoryPage() || !m_batchModeEnabled) {
        return records;
    }

    for (int row = 0; row < m_visibleRecords.size(); ++row) {
        const QTableWidgetItem *item = m_table->item(row, 0);
        if (item != nullptr && item->checkState() == Qt::Checked) {
            records.append(m_visibleRecords.at(row));
        }
    }

    return records;
}

void ManagementPage::showInventoryContextMenu(const QPoint &position)
{
    if (!isInventoryPage()) {
        return;
    }

    const int row = m_table->rowAt(position.y());
    if (row < 0 || row >= m_visibleRecords.size()) {
        return;
    }

    m_table->selectRow(row);

    if (m_batchModeEnabled) {
        return;
    }

    QMenu menu(this);
    menu.setStyleSheet(menuStyle());

    QAction *deleteAction = menu.addAction(QStringLiteral("删除"));
    QAction *selectedAction = menu.exec(m_table->viewport()->mapToGlobal(position));
    if (selectedAction == deleteAction) {
        deleteRecord();
    }
}

void ManagementPage::directUpdateRecord()
{
    const QVariantMap record = selectedRecord();
    if (record.isEmpty()) {
        QMessageBox::information(this, QStringLiteral("提示"), QStringLiteral("请先选择一条库存记录。"));
        return;
    }

    InventoryRecordDialog dialog(QStringLiteral("直接修改库存记录"),
                                 stockEditDialogFields(m_config.fields),
                                 m_storageService,
                                 {QStringLiteral("category"), QStringLiteral("value")},
                                 this);
    dialog.setRecordData(record);
    if (dialog.exec() != QDialog::Accepted) {
        return;
    }

    QString errorMessage;
    if (!m_storageService->applyInventoryChange(dialog.recordData(),
                                                InventoryOperationType::DirectUpdate,
                                                InventoryInputType::Manual,
                                                QStringLiteral("手动直接修改"),
                                                QString(),
                                                0,
                                                &errorMessage)) {
        QMessageBox::critical(this, QStringLiteral("保存失败"), errorMessage);
        return;
    }

    reloadRecords();
}

void ManagementPage::stockInRecord()
{
    switch (selectInventoryActionMode(this,
                                      QStringLiteral("选择入库方式"),
                                      QStringLiteral("请选择入库方式"),
                                      QStringLiteral("手动入库支持多条项目录入；Excel 入库用于从文件批量导入库存字段。"),
                                      QStringLiteral("手动入库"),
                                      QStringLiteral("Excel 入库"))) {
    case InventoryActionModeSelection::Manual:
        manualStockInRecord();
        break;
    case InventoryActionModeSelection::Bom:
        excelStockInRecord();
        break;
    case InventoryActionModeSelection::Cancel:
    default:
        break;
    }
}

void ManagementPage::manualStockInRecord()
{
    ManualStockInDialog dialog(m_config.fields,
                               m_storageService->loadPageRecords(QStringLiteral("inventory")),
                               this);
    if (dialog.exec() != QDialog::Accepted) {
        return;
    }

    int successCount = 0;
    QStringList failures;
    const QList<ManualStockInEntry> pendingEntries = dialog.entries();
    for (int index = 0; index < pendingEntries.size(); ++index) {
        const ManualStockInEntry &entry = pendingEntries.at(index);
        QString errorMessage;
        if (m_storageService->applyInventoryChange(entry.itemData,
                                                   InventoryOperationType::StockIn,
                                                   InventoryInputType::Manual,
                                                   entry.note,
                                                   QString(),
                                                   0,
                                                   &errorMessage)) {
            ++successCount;
            continue;
        }

        failures.append(QStringLiteral("第 %1 条：%2").arg(index + 1).arg(errorMessage));
    }

    reloadRecords();
    QString message = QStringLiteral("成功 %1 条，失败 %2 条。")
                          .arg(successCount)
                          .arg(failures.size());
    if (!failures.isEmpty()) {
        message += QStringLiteral("\n\n") + failures.join(QStringLiteral("\n"));
    }
    showImportResultMessage(this, successCount > 0, message);
}

void ManagementPage::excelStockInRecord()
{
    importInventoryRecords(InventoryOperationType::StockIn);
}

void ManagementPage::stockOutRecord()
{
    switch (selectInventoryActionMode(this,
                                      QStringLiteral("选择出库方式"),
                                      QStringLiteral("请选择出库方式"),
                                      QStringLiteral("手动出库用于对现有库存逐条扣减；BOM 表出库后续用于从文件批量扣减。"),
                                      QStringLiteral("手动出库"),
                                      QStringLiteral("BOM 表出库"))) {
    case InventoryActionModeSelection::Manual:
        manualStockOutRecord();
        break;
    case InventoryActionModeSelection::Bom:
        bomStockOutRecord();
        break;
    case InventoryActionModeSelection::Cancel:
    default:
        break;
    }
}

void ManagementPage::fulfillDemandRecord()
{
    InventoryFulfillmentDialog dialog(m_storageService, this);
    dialog.exec();
    if (dialog.inventoryChanged()) {
        reloadRecords();
    }
}

void ManagementPage::manualStockOutRecord()
{
    const QVariantMap record = selectedRecord();
    if (record.isEmpty()) {
        QMessageBox::information(this, QStringLiteral("提示"), QStringLiteral("请先选择一条库存记录。"));
        return;
    }

    InventoryTransactionDialog dialog(InventoryTransactionDialog::Mode::StockOut,
                                      inventoryRecordSummary(record),
                                      record.value(QStringLiteral("quantity")).toInt(),
                                      this);
    if (dialog.exec() != QDialog::Accepted) {
        return;
    }

    QVariantMap changeRecord;
    changeRecord.insert(QStringLiteral("id"), record.value(QStringLiteral("id")));
    changeRecord.insert(QStringLiteral("quantity"), dialog.quantity());
    changeRecord.insert(QStringLiteral("date"), dialog.transactionDate());

    QString errorMessage;
    if (!m_storageService->applyInventoryChange(changeRecord,
                                                InventoryOperationType::StockOut,
                                                InventoryInputType::Manual,
                                                dialog.note(),
                                                QString(),
                                                0,
                                                &errorMessage)) {
        QMessageBox::critical(this, QStringLiteral("出库失败"), errorMessage);
        return;
    }

    reloadRecords();
}

void ManagementPage::bomStockOutRecord()
{
    const QString filePath = QFileDialog::getOpenFileName(this,
                                                          QStringLiteral("选择 BOM 表"),
                                                          QString(),
                                                          QStringLiteral("Excel 文件 (*.xlsx)"));
    if (filePath.isEmpty()) {
        return;
    }

    QString message;
    const bool success = m_storageService->importInventoryBom(filePath,
                                                              InventoryOperationType::StockOut,
                                                              &message);
    reloadRecords();
    showImportResultMessage(this, success, message);
}

void ManagementPage::importInventoryRecords(InventoryOperationType operationType)
{
    const QString filePath = QFileDialog::getOpenFileName(this,
                                                          QStringLiteral("导入 Excel"),
                                                          QString(),
                                                          QStringLiteral("Excel 文件 (*.xlsx)"));
    if (filePath.isEmpty()) {
        return;
    }

    QString message;
    const bool success = m_storageService->importInventoryExcel(m_config.fields,
                                                                filePath,
                                                                operationType,
                                                                &message);
    if (!success) {
        showImportResultMessage(this, false, message);
        reloadRecords();
        return;
    }

    reloadRecords();
    showImportResultMessage(this, true, message);
}

void ManagementPage::viewInventoryHistory(const QString &inputTypeFilter)
{
    InventoryHistoryDialog dialog(filteredHistoryRecords(m_storageService->loadInventoryHistory(), inputTypeFilter), this);
    dialog.exec();
}

void ManagementPage::addRecord()
{
    QVariantMap data;
    if (isInventoryPage()) {
        InventoryRecordDialog dialog(QStringLiteral("新增%1").arg(m_config.title),
                                     m_config.fields,
                                     m_storageService,
                                     {},
                                     this);
        if (dialog.exec() != QDialog::Accepted) {
            return;
        }
        data = dialog.recordData();
    } else {
        RecordDialog dialog(QStringLiteral("新增%1").arg(m_config.title), m_config.fields, this);
        if (dialog.exec() != QDialog::Accepted) {
            return;
        }
        data = dialog.recordData();
    }

    QString errorMessage;
    if (!m_storageService->upsertRecord(m_config.pageId, data, &errorMessage)) {
        QMessageBox::critical(this, QStringLiteral("保存失败"), errorMessage);
        return;
    }

    reloadRecords();
}

void ManagementPage::editRecord()
{
    const QVariantMap record = selectedRecord();
    if (record.isEmpty()) {
        QMessageBox::information(this, QStringLiteral("提示"), QStringLiteral("请先选择一条记录。"));
        return;
    }

    QVariantMap data;
    if (isInventoryPage()) {
        InventoryRecordDialog dialog(QStringLiteral("编辑%1").arg(m_config.title),
                                     m_config.fields,
                                     m_storageService,
                                     {},
                                     this);
        dialog.setRecordData(record);
        if (dialog.exec() != QDialog::Accepted) {
            return;
        }
        data = dialog.recordData();
    } else {
        RecordDialog dialog(QStringLiteral("编辑%1").arg(m_config.title), m_config.fields, this);
        dialog.setRecordData(record);
        if (dialog.exec() != QDialog::Accepted) {
            return;
        }
        data = dialog.recordData();
    }

    QString errorMessage;
    if (!m_storageService->upsertRecord(m_config.pageId, data, &errorMessage)) {
        QMessageBox::critical(this, QStringLiteral("保存失败"), errorMessage);
        return;
    }

    reloadRecords();
}

void ManagementPage::deleteRecord()
{
    const QVariantMap record = selectedRecord();
    if (record.isEmpty()) {
        QMessageBox::information(this, QStringLiteral("提示"), QStringLiteral("请先选择一条记录。"));
        return;
    }

    const auto answer = QMessageBox::question(this,
                                              QStringLiteral("确认删除"),
                                              QStringLiteral("确认删除当前选中的记录吗？"));
    if (answer != QMessageBox::Yes) {
        return;
    }

    QString errorMessage;
    if (!m_storageService->removeRecord(m_config.pageId, record.value("id").toString(), &errorMessage)) {
        QMessageBox::critical(this, QStringLiteral("删除失败"), errorMessage);
        return;
    }

    reloadRecords();
}

void ManagementPage::toggleBatchMode()
{
    if (!isInventoryPage()) {
        return;
    }

    m_batchModeEnabled = !m_batchModeEnabled;
    if (m_batchModeButton != nullptr) {
        m_batchModeButton->setChecked(m_batchModeEnabled);
        m_batchModeButton->setText(m_batchModeEnabled ? QStringLiteral("退出批量") : QStringLiteral("批量操作"));
    }
    if (m_batchDeleteButton != nullptr) {
        m_batchDeleteButton->setVisible(m_batchModeEnabled);
    }

    configureTableColumns();
    reloadRecords();
}

void ManagementPage::deleteCheckedRecords()
{
    const QList<QVariantMap> records = checkedRecords();
    if (records.isEmpty()) {
        QMessageBox::information(this, QStringLiteral("提示"), QStringLiteral("请先勾选要删除的库存记录。"));
        return;
    }

    const auto answer = QMessageBox::question(this,
                                              QStringLiteral("确认批量删除"),
                                              QStringLiteral("确认删除已勾选的 %1 条库存记录吗？").arg(records.size()));
    if (answer != QMessageBox::Yes) {
        return;
    }

    int successCount = 0;
    QStringList failures;
    for (const QVariantMap &record : records) {
        QString errorMessage;
        if (m_storageService->removeRecord(m_config.pageId, record.value("id").toString(), &errorMessage)) {
            ++successCount;
        } else {
            const QString label = record.value(QStringLiteral("manufacturerPart")).toString().trimmed();
            failures.append(QStringLiteral("%1：%2")
                                .arg(label.isEmpty() ? record.value("id").toString() : label,
                                     errorMessage));
        }
    }

    reloadRecords();

    QString message = QStringLiteral("成功删除 %1 条，失败 %2 条。")
                          .arg(successCount)
                          .arg(failures.size());
    if (!failures.isEmpty()) {
        message += QStringLiteral("\n\n") + failures.join(QStringLiteral("\n"));
    }

    if (failures.isEmpty()) {
        QMessageBox::information(this, QStringLiteral("批量删除完成"), message);
        return;
    }

    QMessageBox box(this);
    box.setIcon(successCount > 0 ? QMessageBox::Information : QMessageBox::Warning);
    box.setWindowTitle(successCount > 0 ? QStringLiteral("批量删除完成") : QStringLiteral("批量删除失败"));
    box.setText(message.split(QChar('\n')).first());
    box.setDetailedText(failures.join(QStringLiteral("\n")));
    box.exec();
}

void ManagementPage::saveSelectedAttachments()
{
    if (!isReimbursementPage()) {
        return;
    }

    const QVariantMap record = selectedRecord();
    if (record.isEmpty()) {
        QMessageBox::information(this, QStringLiteral("提示"), QStringLiteral("请先选择一条报账记录。"));
        return;
    }

    const bool hasAttachments = !record.value(QStringLiteral("invoiceAttachment")).toString().trimmed().isEmpty()
                                || !record.value(QStringLiteral("otherAttachments")).toString().trimmed().isEmpty();
    if (!hasAttachments) {
        QMessageBox::information(this, QStringLiteral("提示"), QStringLiteral("当前记录没有可另存的附件。"));
        return;
    }

    const QString targetDirectory = QFileDialog::getExistingDirectory(this,
                                                                      QStringLiteral("选择附件保存目录"),
                                                                      QString());
    if (targetDirectory.isEmpty()) {
        return;
    }

    QList<ReimbursementAttachmentContent> attachments;
    QString errorMessage;
    if (!m_storageService->loadReimbursementAttachments(record, &attachments, &errorMessage)) {
        QMessageBox::critical(this, QStringLiteral("另存失败"), errorMessage);
        return;
    }

    int successCount = 0;
    QStringList failures;
    for (const ReimbursementAttachmentContent &attachment : attachments) {
        const QString fileName = attachment.fileName.trimmed().isEmpty()
                                     ? displayAttachmentName(attachment.reference)
                                     : attachment.fileName.trimmed();
        const QString targetFilePath = uniqueFilePath(targetDirectory,
                                                      fileName.isEmpty() ? QStringLiteral("attachment.bin") : fileName);
        QFile file(targetFilePath);
        if (!file.open(QIODevice::WriteOnly)) {
            failures.append(QStringLiteral("%1：%2").arg(QFileInfo(targetFilePath).fileName(), file.errorString()));
            continue;
        }

        if (file.write(attachment.content) != attachment.content.size()) {
            failures.append(QStringLiteral("%1：写入不完整").arg(QFileInfo(targetFilePath).fileName()));
            continue;
        }

        ++successCount;
    }

    QString message = QStringLiteral("成功另存 %1 个附件。").arg(successCount);
    if (!failures.isEmpty()) {
        message += QStringLiteral("\n\n失败明细：\n") + failures.join(QStringLiteral("\n"));
    }

    if (failures.isEmpty()) {
        QMessageBox::information(this, QStringLiteral("另存完成"), message);
    } else {
        QMessageBox::warning(this, QStringLiteral("部分附件另存失败"), message);
    }
}

void ManagementPage::downloadInvoiceAttachment(int row)
{
    if (!isReimbursementPage() || row < 0 || row >= m_visibleRecords.size()) {
        return;
    }

    const QVariantMap record = m_visibleRecords.at(row);
    const QStringList references = splitAttachmentReferences(record.value(QStringLiteral("invoiceAttachment")));
    if (references.isEmpty()) {
        QMessageBox::information(this, QStringLiteral("提示"), QStringLiteral("当前记录没有发票附件。"));
        return;
    }

    QList<ReimbursementAttachmentContent> attachments;
    QString errorMessage;
    if (!m_storageService->loadReimbursementAttachments(record, &attachments, &errorMessage)) {
        QMessageBox::critical(this, QStringLiteral("下载失败"), errorMessage);
        return;
    }

    const QString reference = references.constFirst().trimmed();
    const auto attachmentIt = std::find_if(attachments.cbegin(),
                                           attachments.cend(),
                                           [&reference](const ReimbursementAttachmentContent &attachment) {
                                               return attachment.reference.trimmed() == reference;
                                           });
    if (attachmentIt == attachments.cend()) {
        QMessageBox::warning(this, QStringLiteral("下载失败"), QStringLiteral("未找到当前记录对应的发票附件内容。"));
        return;
    }

    const QString defaultFileName = attachmentIt->fileName.trimmed().isEmpty()
                                        ? displayAttachmentName(reference)
                                        : attachmentIt->fileName.trimmed();
    const QString targetFilePath = QFileDialog::getSaveFileName(this,
                                                                QStringLiteral("保存发票附件"),
                                                                defaultFileName,
                                                                QStringLiteral("PDF 文件 (*.pdf);;所有文件 (*.*)"));
    if (targetFilePath.isEmpty()) {
        return;
    }

    QFile file(targetFilePath);
    if (!file.open(QIODevice::WriteOnly)) {
        QMessageBox::critical(this, QStringLiteral("下载失败"), file.errorString());
        return;
    }

    if (file.write(attachmentIt->content) != attachmentIt->content.size()) {
        QMessageBox::critical(this, QStringLiteral("下载失败"), QStringLiteral("附件写入不完整。"));
        return;
    }

    QMessageBox::information(this,
                             QStringLiteral("下载完成"),
                             QStringLiteral("发票附件已保存到：\n%1").arg(QDir::toNativeSeparators(targetFilePath)));
}

void ManagementPage::importRecords()
{
    const QString filePath = QFileDialog::getOpenFileName(this,
                                                          QStringLiteral("导入 Excel"),
                                                          QString(),
                                                          QStringLiteral("Excel 文件 (*.xlsx)"));
    if (filePath.isEmpty()) {
        return;
    }

    QString errorMessage;
    if (!m_storageService->importExcel(m_config.pageId, m_config.fields, filePath, &errorMessage)) {
        QMessageBox::critical(this, QStringLiteral("导入失败"), errorMessage);
        return;
    }

    reloadRecords();
}

void ManagementPage::exportRecords()
{
    const QString filePath = QFileDialog::getSaveFileName(this,
                                                          QStringLiteral("导出 Excel"),
                                                          m_config.pageId + QStringLiteral(".xlsx"),
                                                          QStringLiteral("Excel 文件 (*.xlsx)"));
    if (filePath.isEmpty()) {
        return;
    }

    QString errorMessage;
    if (!m_storageService->exportExcel(m_config.pageId, m_config.fields, m_config.title, filePath, &errorMessage)) {
        QMessageBox::critical(this, QStringLiteral("导出失败"), errorMessage);
        return;
    }

    QMessageBox::information(this, QStringLiteral("导出完成"), QStringLiteral("Excel 已导出。"));
}